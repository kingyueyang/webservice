## 依赖组件：
1. zookeeper 3.4.6
2. uwsgi 2.0.11.x

## 依赖第三方开发包：
1. kazoo 2.2.x
2. pycrypto 2.6.x
3. input.thrift生成的python包（需要设置python路径）
4. harpc的python开发包（需要设置python路径）


## 安装步骤：
1. 部署到不同的环境，需要更改./src/settings.py中的ZK_ADDRESS内容（zookeeper地址），./etc/harpc.conf中的zk_connect_str内容（zookeeper地址）以及service内容（dataProcessService服务名）
2. 修改./bin/start.sh文件中--http配置后的ip和port，修改为服务监听的ip和port

## 运行方式：
1. 启动：cd到bin目录下，运行命令sh start.sh命令，启动参数说明如下：
```
--socket：监听的ip:port（在启动之前，需要修改ip和port为本机的ip和port）
--pidfile：保存进程pid的文件
--file：服务入口文件位置
-b：内存大小
-M：开启master进程
-p：worker进程数
--threads：每个进程的线程数
--daemonize：后台运行
/tmp/webSerivice.log：保存uwsgi日志的文件位置（若无需保存，可配置为/dev/null）
```

## 验证方法：
cd到log目录下，打开一个日志文件（存在日志文件），能看到打印的"apis info is ..." 和"customers info is ..."代表启动成功了

## 停止：
cd到bin目录下，运行命令sh stop.sh命令；

## 重启：
cd到bin目录下，运行命令sh restart.sh命令；

## 注意事项：
1. 在配置nginx转发时，需要保持请求头部中HOST不变，可以在nginx配置文件中设置 proxy_set_header Host $http_host 保证HOST不变