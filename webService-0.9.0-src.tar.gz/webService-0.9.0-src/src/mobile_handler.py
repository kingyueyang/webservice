# -*- coding: utf-8 -*-
import logging
import settings
import json
import utils
import time
import types


def config_handler(env, appkey, param):
    ''' deal request method of OnlineConfig '''
    header = [("Content-Type", "application/json"),]

    # get config
    config = utils.get_onlineconfig(appkey)
    if not config:
        status = '400 Bad Request'
        logging.error('wrong appkey')
        body = [settings.ResponseCodeErrOther, "Wrong appkey"]
        return status, header, body, None

    # get gid
    gid_inparam = param.get('gid', None)

    if not gid_inparam:
        config["gid"] = utils.get_gid(param)
    else:
        config["gid"] = gid_inparam

    result = [0, "OK", config]
    logging.debug("newonlineconfig:%s" % json.dumps(result))
    status = '200 OK'
    return status, header, result, None


def default_handler(env, appkey ,param, method):
    ''' deal request method of Multi and Other Method'''

    header = [("Content-Type", "application/json"),]

    # if method is Multi, field of requests may be a str type, must transfer to json type
    if 'Multi' == method:
        requests = param.get('requests', '')
        if types.StringType == type(requests) and requests:
            requests = json.loads(requests)
            param['requests'] = requests



    # add auto params
    param[settings.PARAM_IP] = utils.get_request_ip(env)
    param[settings.PARAM_AGENT] = env.get('HTTP_USER_AGENT', '')


    if 'Multi' == method:
        req_list = utils.split_requests(param)
        if  0 == len(req_list):
            logging.error("Invalid Request")
            body = [settings.ResponseCodeErrOther, "Invalid Request"]
            status ="400 Bad Request"
            return status, header, body, None

        # add uuid, timestamp, must be unique in each request param
        for param_one in req_list:
            param_one[settings.PARAM_UUID] = utils.get_uuid()
            param_one[settings.PARAM_TIME] = '%.3f' % time.time()
        logging.debug("send %s to dataProcessService" % json.dumps(req_list))
        body = utils.call_rpc(json.dumps(req_list))
        status = "200 OK"

        return status, header, body, None

    # one method
    else:
        # add method, uuid,timestamp
        param[settings.PARAM_METHOD] = method
        uuid = utils.get_uuid()
        param[settings.PARAM_UUID] = uuid
        param[settings.PARAM_TIME] = '%.3f' % time.time()
        params_list = []
        params_list.append(param)
        logging.debug("send %s to dataProcessService" % json.dumps(params_list))
        body = utils.call_rpc(json.dumps(params_list))
        status = "200 OK"

        return status, header, body, uuid



def mobile_handler(env, appkey, param, method, env_param):
    '''
    :param env: uwsgi env
    :param appkey: appkey of request
    :param param: json-format request param
    :param method: method of request
    :return: status, header, body
    '''

    header = [("Content-Type", "application/json"),]


    # authenticate
    if not utils.authenticate(env, env_param):
        status = '401 Unauthorized'
        logging.error('Bad authentication data')
        body = [settings.ResponseCodeErrOther, "Bad authentication data"]
        return status, header, body, None

    if  'OnlineConfig' == method:
        return config_handler(env, appkey, param)

    else:
        return default_handler(env, appkey, param, method)

