# -*- coding: utf-8 -*-
from kazoo.client import KazooClient
from kazoo.retry import KazooRetry
import threading
from settings import DEFAULT_ZK_CONNECTION_TIMEOUT
from settings import DEFAULT_ZK_OPERATION_RETRY


class ZKClientManager(KazooClient):
    __client_dict = {}
    __lock = threading.RLock()

    @classmethod
    def make(cls, hosts):
        with cls.__lock:
            if hosts in cls.__client_dict:
                return cls.__client_dict.get(hosts)
            else:
                client = cls(hosts)
                client.start()
                cls.__client_dict[hosts] = client
                return client

    def __init__(self, hosts):
        retry = KazooRetry(max_delay=DEFAULT_ZK_OPERATION_RETRY)
        super(ZKClientManager, self).__init__(hosts=hosts, timeout=DEFAULT_ZK_CONNECTION_TIMEOUT,connection_retry=retry, command_retry=retry)
        #super(ZKClientManager, self).__init__(hosts=hosts, timeout=DEFAULT_ZK_CONNECTION_TIMEOUT)

