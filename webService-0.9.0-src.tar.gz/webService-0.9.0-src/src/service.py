# -*- coding: utf-8 -*-

import uwsgi
import logging
import traceback
import settings
import utils
from mobile_handler import mobile_handler
from pc_handler import pc_handler
import json
import types
import time

def init_functions():
    ''' when the service start, this function will be called. '''
    utils.init_log()
    utils.init_global_var()
    utils.init_conn()
    utils.init_zk_config()

# set the function to call after each fork()
uwsgi.post_fork_hook=init_functions


def default_handler(env):

    header = [('Content-Type', 'text/html')]

    req_method = env['REQUEST_METHOD']
    path_info = env['PATH_INFO']
    env_param = utils.get_param(env)
    #utils.set_global_param(env_param)

    # request '/favicon.ico', broswer auto send, ingored！！！
    if '/favicon.ico' == path_info:
        status = '404 Not Found'
        return status, header, '', None

    if req_method not in ['GET', 'POST']:
        body = [settings.ResponseCodeErrInvalidMethod, "Invalid HTTP Method"]
        status = '400 Bad Request'
        return status, header, body, None

    # get the method
    method = path_info[path_info.rindex('/')+1:-3]
    logging.debug("method:%s", method)

    # method is '' or None
    if not method:
        body = [settings.ResponseCodeErrInvalidMethod, "Empty Method"]
        status = '400 Bad Request'
        return status, header, body, None

    # unzip the param
    uzip_status, uzip_data, uzip_msg = utils.uzip(env, env_param)
    logging.debug("after uzip, unzip_data:%s, uzip_status:%s, uzip_msg:%s" % (uzip_data ,uzip_status ,uzip_msg))

    # unzip failed
    if uzip_status != 0:
        status = '400 Bad Request'
        logging.error(uzip_msg)
        body = [settings.ResponseCodeErrOther, ]
        body.append(uzip_msg)
        return status, header, body, None

    # decode according to the flag of the request header
    dec_data = utils.decode_content(env, uzip_data)
    if not dec_data:
        status = '400 Bad Request'
        body = [settings.ResponseCodeErrOther, 'decode data failed']
        return status, header, body, None
    logging.debug("param after decode, dec_data: %s" % (dec_data))

    param = None
    try:
        if 'GET' == req_method:
            param = utils.parse_query_string(dec_data)
        else:
            param = json.loads(dec_data,)
    except:
        status = '400 Bad Request'
        logging.error('post params are not json format')
        body = [settings.ResponseCodeErrParameterType, "params are not correct format"]
        return status, header, body, None

    logging.info('after transfer to json format, param is %s' % json.dumps(param, ensure_ascii=False))
    # get the appkey
    appkey = utils.get_appkey(param)
    if not appkey:
        logging.error('param has no appkey or appkey is invalid')
        status = '400 Bad Request'
        body = [settings.ResponseCodeErrOther, "param has no appkey or appkey is invalid"]
        return status, header, body, None

    # get the termnal type
    terminal = utils.get_terminal_from_appkey(appkey)
    # mobile
    if terminal in settings.MOBILE_TERMINAL:
        return mobile_handler(env, appkey, param, method, env_param)
    # pc
    elif settings.PC_TERMINAL == terminal:
        return pc_handler(env, appkey, param, method)
    # invalid terminal
    else:
        logging.error('appkey terminal type is invalid')
        status = '400 Bad Request'
        body = [settings.ResponseCodeErrOther, 'the appkey terminal type is invalid']
        return status, header, body, None


def application(env, start_response):
    '''uwsgi enter'''
    try:
        logging.debug('env is %s' % env)
        start_time = time.time()
        status, header, body, uuid = default_handler(env)
        logging.debug("status:%s, header:%s, body:%s", status, header, body)
        start_response(status, header)
        end_time = time.time()
        all_time = int((end_time - start_time) * 1000)
        if types.ListType == type(body) and settings.SHOW_TIME:
            if 3 == len(body):
                body[-1]['all_time'] = all_time
                if uuid and settings.SHOW_UUID:
                    body[-1]['uuid'] = uuid
            else:
                time_info = {}
                time_info['all_time'] = all_time
                if uuid and settings.SHOW_UUID:
                    time_info['uuid'] = uuid
                body.append(time_info)
            yield json.dumps(body)

        elif types.ListType == type(body):
            yield json.dumps(body)

        else:
            yield body

    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error("error info is %s" % e)
        start_response('500 Internal Server Error', [])
        if settings.DEBUG:
            yield traceback.format_exc()
        else:
            yield json.dumps([settings.ResponseCodeErrOther, 'Internal Server Error!'])
