# -*- coding: utf-8 -*-
DEBUG = False
SHOW_TIME = False
SHOW_UUID = False

DEFAULT_HEADER = [("Content-Type", "application/x-javascript"),
("P3P", "CP=\"CAO \
DSP COR CUR ADM DEV TAI PSA PSD IVAi IVDi CONi TELo OTPi OUR DELi SAMi \
OTRi UNRi PUBi IND PHY ONL UNI PUR FIN COM NAV INT DEM CNT STA POL HEA \
PRE GOV\"")]

# auto params
PARAM_METHOD = "method"
PARAM_IP = "ip"
PARAM_REF_PAGE = "ref_page"
PARAM_AGENT = "user_agent"
PARAM_GID = "gid"
PARAM_UUID = "uuid"
PARAM_IS_NEWGID = "is_newgid"
PARAM_TIME = "timestamp"




# the secret to gen md5 of Authorization
SECRET="jleboroolRlxFnqqgoxlpavvhszxaxnmikiquu2zifm4yzatarvyijh@qkqussrz"

# the enc type in request header
MOBILE_ENCRYPT = 'HTTP_MENC'

# the md5 of Authorization in request header
Authorization = 'HTTP_AUTHORIZATION'

# terminal type
PC_TERMINAL = 'PC'
MOBILE_TERMINAL = ['MOBILE', 'iOS', 'Android']

# zk address
ZK_ADDRESS = "ZK_ADDR"

# zk connect settings
DEFAULT_ZK_CONNECTION_TIMEOUT = 15  # unit s
DEFAULT_ZK_OPERATION_RETRY = 3

# zk path
ZK_PROBE_PATH = "/baseline4/input/probes"
ZK_APIS_PATH = "/baseline4/input/apis"

# cookie expire date
COOKIES_EXPIRE = 3*365*24*3600

ReqponseCodeOK = 0
ResponseCodeErrInvalidMethod = 1
ResponseCodeErrInvalidCustomer = 2
ResponseCodeErrMissingParameter = 3
ResponseCodeErrParameterType = 4
ResponseCodeErrOther = 5
