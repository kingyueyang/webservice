# -*- coding: utf-8 -*-
import logging
import settings
import json
import utils
import time
import types
import traceback
import copy

'''
PC端协议数据处理函数
'''
def pc_handler(request, appkey, param, method):

    body = None
    header = copy.deepcopy(settings.DEFAULT_HEADER)
    status = '200 OK'
    invalid = False

    # check the encoding and characters
    for k, v in param.iteritems():
        if not(v and v.strip()):
            continue
        gbk = False
        a = None

        if not isinstance(v, types.UnicodeType):
            try:
                a = v.decode('utf-8')
            except Exception:
                gbk = True
                try:
                    a = v.decode('gb2312')
                except Exception, e:
                    logging.error(traceback.format_exc())
                    logging.error('error info is %s' % e)
                    invalid = True
                    body = [settings.ResponseCodeErrOther, ]
                    msg = "'%s' value is not utf-8 or gb2312 encode-format" % k
                    body.append(msg)
                    break
            if gbk:
                param[k] = a.encode('utf-8')
            else:
                param[k] = v


    if invalid :
        status = '400 Bad Request'
        return status, header, body, None

    # if method is Multi, field of requests may be a str type, must transfer to json type
    if 'Multi' == method:
        requests = param.get('requests', '')
        if types.StringType == type(requests) and requests:
            requests = json.loads(requests)
            param['requests'] = requests

    # get gid
    gid, is_new, set_cookie, cookies = utils.get_gid_from_cookie(request, param)

    ret_val = ''

    # synchronization of gid
    if method == 'StdID':
        if ('bfdid' in param) and (param['bfdid'] == '1'):
            if ('callback' not in param):
                if ('HTTP_IF_MODIFIED_SINCE' not in request) or \
                    (cookies.has_key('cachedel') and cookies["cachedel"].value == '1') or \
                    (request['HTTP_IF_MODIFIED_SINCE'] == 'Thu, 01 Jan 1970 08:00:00 GMT'):
                    ts = time.strftime("%a, %d %b %Y %T GMT", time.gmtime(time.time()))
                    header.append(("Last-Modified", ts))
                    ret_val = 'BCore.prototype.options.gid="%s";' % gid
                else:
                    status = '304 Not Modifed'
            else:
                if ('HTTP_IF_MODIFIED_SINCE' not in request) or \
                    (cookies.has_key('cachedel') and cookies["cachedel"].value == '1') or \
                    (request['HTTP_IF_MODIFIED_SINCE'] == 'Thu, 01 Jan 1970 08:00:00 GMT'):
                    ts = time.strftime("%a, %d %b %Y %T GMT", time.gmtime(time.time()))
                    header.append(("Last-Modified", ts))
                    ret_val = '%s("%s")' % (param['callback'], gid)
                else:
                    status = '304 Not Modifed'
        else:
            ret_val = [0, 'OK', gid]
            if 'callback' in param:
                callback = param['callback']
                if callback:
                    ret_val = json.dumps(ret_val)
                    ret_val = callback + '(' + ret_val + ')'

        if set_cookie:
            utils.set_gid_cookie(header, gid, utils.get_domain(request))

        return status, header, ret_val, None

    else:

        # add auto param
        param[settings.PARAM_IP] = utils.get_request_ip(request)
        param[settings.PARAM_REF_PAGE] = request.get("HTTP_REFERER", "")
        param[settings.PARAM_AGENT] = request.get('HTTP_USER_AGENT', "")
        param[settings.PARAM_GID] = gid
        param[settings.PARAM_IS_NEWGID] = is_new


        if 'Multi' == method:
            param_list = utils.split_requests(param)

            if  0 == len(param_list):
                logging.error("Invalid Request")
                body = [settings.ResponseCodeErrOther, "Invalid Request"]
                status ="400 Bad Request"
                return status, header, body, None

            # add uuid, timestamp, must be unique in each request param
            for param_one in param_list:
                param_one[settings.PARAM_UUID] = utils.get_uuid()
                param_one[settings.PARAM_TIME] = '%.3f' % time.time()

            if set_cookie:
                utils.set_gid_cookie(header, gid, utils.get_domain(request))

            logging.debug("send %s to dataProcessService" % json.dumps(param_list))
            body = utils.call_rpc(json.dumps(param_list))
            status = "200 OK"

            return status, header, body, None
        # one method
        else:
            # 判断该api是否需要重定向，根据重定向URL，重定向请求至该URL
            redirect_url = utils.get_redirect_url(method, param)
            # redirect_url is not None
            if redirect_url:
                if isinstance(redirect_url, types.UnicodeType):
                    redirect_url = redirect_url.encode('utf-8')
                status = "302 Found"
                header = [("Location", redirect_url),]
                return status, header, "", None

            # 对于只有一条method，需要判断该API是否要设置set_cookie
            api_setcookie = utils.get_api_setcookie(method)
            logging.debug('set_cookie: %s, api_setcookie:%s', set_cookie, api_setcookie)

            if set_cookie and api_setcookie:
                utils.set_gid_cookie(header, gid, utils.get_domain(request))

            # add method, uuid,timestamp
            param[settings.PARAM_METHOD] = method
            uuid = utils.get_uuid()
            param[settings.PARAM_UUID] = uuid
            param[settings.PARAM_TIME] = '%.3f' % time.time()
            params_list = []
            params_list.append(param)
            logging.debug("send %s to dataProcessService" % json.dumps(params_list))
            body = utils.call_rpc(json.dumps(params_list))
            status = "200 OK"
            return status, header, body, uuid


