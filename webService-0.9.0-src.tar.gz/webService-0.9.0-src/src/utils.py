# -*- coding: utf-8 -*-
import hashlib
import logging
from kazoo.protocol.states import KazooState
import settings
from cStringIO import StringIO
import gzip
import traceback
import base64
import os
import uuid
import time
import Cookie
import json
import re
from zk_client import ZKClientManager
import threading
import sys
import logging.handlers
from Crypto.Cipher import DES
import urlparse
import types
from bfd.input import Handler # 导入thrift生成的service
from bfd.harpc import client  # 导入harpc 的client
from bfd.harpc.common import config # 导入harpc 配置库
import copy

g_gid_num = 0
g_gid_lock = None
g_uuid_num = 0
g_uuid_lock = None
g_process_id = None

g_zk_op = None
g_rpc_client = None

g_probes_info = {}
g_apis_info = {}
g_probes_lock = None
g_apis_lock = None

# param of request
#g_req_param = None
#g_param_lock = None

g_work_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#DES解密相关参数
BS = DES.block_size
pad = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS)
unpad = lambda s : s[0:-ord(s[-1])]

des_key = '660ea0ab'
desObj=DES.new(des_key, DES.MODE_ECB)


def get_appkey(param):
    ''' get appkey '''
    global g_probes_info, g_probes_lock


    appkey = param.get('appkey', None)
    if not appkey:
        return None

    try:
        b_valid = True
        g_probes_lock.acquire()
        if appkey not in g_probes_info.keys():
            b_valid = False
        g_probes_lock.release()

        if b_valid:
            return appkey
        else:
            return None

    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)

        if g_probes_lock.locked():
            g_probes_lock.release()

        return None



def get_api_setcookie(method):
    ''' get if need set cookie from  g_apis_info '''
    global g_apis_info, g_apis_lock
    try:
        g_apis_lock.acquire()
        if method not in g_apis_info.keys():
            set_cookie =  False
        else:
            set_cookie = g_apis_info[method].get('set_cookie', False)
        g_apis_lock.release()
        return set_cookie

    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)

        if g_apis_lock.locked():
            g_apis_lock.release()

        return False

def get_redirect_url(method, param):
    ''' get redirect url according by method'''
    global g_apis_info, g_apis_lock

    redirect_url = None

    try:
        g_apis_lock.acquire()
        if method in g_apis_info.keys():
            redirect_jump = g_apis_info[method].get('redirect_jump', {})
            if redirect_jump:
                jump_type = redirect_jump.get('jump_type', '')
                if 'address' == jump_type:
                    redirect_url = redirect_jump.get('target', '')
                elif 'param' == jump_type:
                    param_name = redirect_jump.get('target', '')
                    redirect_url = param.get(param_name, '')

        g_apis_lock.release()


    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)

        if g_apis_lock.locked():
            g_apis_lock.release()

        return None

    return redirect_url


def get_terminal_from_appkey(appkey):
    ''' get terminal by appkey '''
    global g_probes_info, g_probes_lock

    terminal = ''
    try:
        g_probes_lock.acquire()
        terminal = g_probes_info[appkey].get('terminal', '')
        g_probes_lock.release()
    except Exception,e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)

        if g_probes_lock.locked():
            g_probes_lock.release()


    return terminal



def get_cid_from_appkey(appkey):
    ''' get cid by appkey '''
    global g_probes_info, g_probes_lock

    cid = ''
    try:
        g_probes_lock.acquire()
        cid = g_probes_info[appkey].get('cid', '')
        g_probes_lock.release()
    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)
        if g_probes_lock.locked():
            g_probes_lock.release()

    return cid

def get_item_type(appkey):
    ''' get item_type by appkey '''
    global g_probes_info, g_probes_lock

    item_type = ''
    try:
        g_probes_lock.acquire()
        item_type = g_probes_info[appkey].get('item_type', '')
        g_probes_lock.release()
    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)
        if g_probes_lock.locked():
            g_probes_lock.release()

    return item_type



def get_onlineconfig(appkey):
    ''' get onlineconfig by appkey '''
    global g_probes_info, g_probes_lock

    online_config = {}
    try:
        g_probes_lock.acquire()
        online_config = g_probes_info[appkey].get('mobile_config', {})
        g_probes_lock.release()
    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error('error info is %s' % e)
        if g_probes_lock.locked():
            g_probes_lock.release()

    return online_config




def set_global_apis(apis_info):
    global g_apis_info
    g_apis_info = apis_info

def set_api_datawatch(path):
    global g_apis_info
    @g_zk_op.DataWatch(path=path,allow_session_lost=True)
    def watch_api_data(data, stat, event):
        if event and event.type == 'CHANGED':
            try:
                json_value = json.loads(data)
                name = json_value.get('name', '')
                if name:
                    g_apis_info[name] = json_value
                    logging.info('api %s content will change' % name)
            except:
                logging.error('handle error : %s' % data)
                logging.error(traceback.format_exc())


def set_apis_childrenwatch():
    @g_zk_op.ChildrenWatch(path=settings.ZK_APIS_PATH,allow_session_lost=True)
    def watch_apis_children(children):
        global g_zk_op
        apis_info = {}
        for child in children:
            path = '%s/%s' % (settings.ZK_APIS_PATH, child)
            child_value = g_zk_op.get(path)
            try:

                json_value = json.loads(child_value[0])
                name = json_value.get('name', '')
                if name:
                    apis_info[name] = json_value
            except:
                logging.error('handle error : %s' % child_value[0])
                logging.error(traceback.format_exc())

            set_api_datawatch(path)

        set_global_apis(apis_info)
        logging.info("apis info is %s" % json.dumps(apis_info.keys()))


def set_global_probes(probes_info):
    global g_probes_info
    g_probes_info = probes_info

def set_probe_datawatch(path):
    global g_probes_info
    @g_zk_op.DataWatch(path,allow_session_lost=True)
    def watch_probe_data(data, stat, event):
        if event and event.type == 'CHANGED':
            try:
                json_value = json.loads(data)
                appkey = json_value.get('appkey', '')
                if appkey:
                    g_probes_info[appkey] = json_value
                    logging.info('probe %s content will change' % appkey)
            except:
                logging.error('handle error : %s' % data)
                logging.error(traceback.format_exc())


def set_probes_childrenwatch():
    @g_zk_op.ChildrenWatch(settings.ZK_PROBE_PATH,allow_session_lost=True)
    def watch_probes_children(children):
        global g_zk_op
        probes_info = {}
        for child in children:
            path = '%s/%s' % (settings.ZK_PROBE_PATH, child)
            child_value = g_zk_op.get(path)
            try:

                json_value = json.loads(child_value[0])
                appkey = json_value.get('appkey', '')
                if appkey:
                    probes_info[appkey] = json_value
            except:
                logging.error('handle error : %s' % child_value[0])
                logging.error(traceback.format_exc())

            set_probe_datawatch(path)

        set_global_probes(probes_info)
        logging.info("probes info is %s" % json.dumps(probes_info.keys()))


def init_zk_config():
    ''' init apis info, probes info from zookeeper '''
    global g_apis_info, g_probes_info

    if not g_probes_info:
        set_probes_childrenwatch()

    if not g_apis_info:
        set_apis_childrenwatch()




def init_global_var():
    ''' init global var '''
    global g_work_dir, g_machine_id, g_process_id, g_zk_op, g_probes_lock, g_apis_lock, g_uuid_num, g_gid_num, g_gid_lock, g_uuid_lock#, g_param_lock

    g_zk_op = ZKClientManager.make(settings.ZK_ADDRESS)
    g_zk_op.add_listener(zk_listener)
    #g_zk_op.start()

    g_probes_lock = threading.Lock()
    g_apis_lock = threading.Lock()
    g_gid_lock = threading.Lock()
    g_uuid_lock = threading.Lock()
    #g_param_lock = threading.Lock()

    logging.debug('process id is %d' % g_process_id)
    logging.debug('machine id is %s' % g_machine_id)
    logging.debug('uuid num is %d' % g_uuid_num)
    logging.debug('gid num is %d' % g_gid_num)
    logging.debug("work dir is %s" % g_work_dir)



def init_log():
    ''' int logging config '''
    global g_process_id, g_work_dir
    g_process_id = os.getpid()
    try:
        debug = settings.DEBUG
        logger = logging.getLogger()

        log_path = '%s/log' % (g_work_dir)
        if not os.path.exists(log_path):
            os.makedirs(log_path, mode= 0775)
        filename = '%s/log/%s_webservice_backend.log' % (g_work_dir,g_process_id)

        hdlr = logging.handlers.RotatingFileHandler(filename, "a", 102400000, 10)

        fmt_str = '[%(levelname)s %(asctime)s @ %(process)d %(thread)d] (%(filename)s/%(funcName)s:%(lineno)d) - %(message)s'

        formatter = logging.Formatter(fmt_str)
        hdlr.setFormatter(formatter)
        logger.addHandler(hdlr)
        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.INFO)
    except Exception, e:
        print "Some error occurs while initial log server, %s" % e
        sys.exit(0)



def init_conn():
    ''' init rpc connection with dataProcessService'''
    global g_rpc_client, g_work_dir

    try:
        conf_file = '%s/etc/harpc.conf' % (g_work_dir, )
        print 'conf_file is %s' % conf_file
        conf = config.Config(conf_file) #读取配置文件

        manager = client.Client(Handler.Client, conf)  #Handler.Client,   thrift生成的Client
        g_rpc_client = manager.create_proxy()
    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error("error info is %s" % e)
        sys.exit(0)

def get_machine_id():
    ''' 使用uuid的一部分标识一台机器，代替ip和hostname, 记录在当前目录的mmark.uuid中
        这样可以保证uuid的相对稳定性
    '''
    global g_work_dir
    filename = '%s/%s/%s' % (g_work_dir, 'etc', 'mmark.uuid')
    if os.access(filename, os.R_OK):
        fn = open(filename, "r")
        mid = fn.readline().strip()
        fn.close()
        if mid:
            return mid
    # use machine specific uuid, last 16 char will be the same if machine is the same
    mid = uuid.uuid1().get_hex()[16:]
    # save it and return it
    fn = open(filename, "w")
    fn.write(mid)
    fn.close()
    return mid

g_machine_id = get_machine_id()


def get_uuid() :
    """ 生成api调用用到的uuid
    """
    global g_uuid_num, g_machine_id, g_process_id, g_uuid_lock

    g_uuid_lock.acquire()

    g_uuid_num += 1
    logging.debug("uuid: Input:%s%08x%08x%x",g_machine_id, g_process_id, g_uuid_num, int(time.time()))
    uuid = "Input:%s:%08x:%08x:%x" % (g_machine_id, g_process_id, g_uuid_num, time.time())

    g_uuid_lock.release()

    return uuid



'''
获取get/post参数
'''
def get_param(env):
    ''' support: POST, GET request '''
    req_method = env['REQUEST_METHOD']
    if req_method.upper() == 'POST':
        try:
            request_body_size = int(env.get('CONTENT_LENGTH', 0))
        except:
            request_body_size = 0
            logging.error('get content length error: %s' % (traceback.format_exc()))
        return env['wsgi.input'].read(request_body_size)
    return env['QUERY_STRING']


# def get_global_param():
#     ''' 获取全局变量g_req_param '''
#     global g_req_param, g_param_lock
#     g_param_lock.acquire()
#     param = copy.deepcopy(g_req_param)
#     g_param_lock.release()
#     return param
#
# def set_global_param(param):
#     ''' 设置全局变量g_req_param '''
#     global g_req_param, g_param_lock
#     g_param_lock.acquire()
#     g_req_param = param
#     g_param_lock.release()


def parse_query_string(query_str):
    ''' parse url query string, get dict represent for query params '''
    return {k: v for k, v in urlparse.parse_qsl(query_str)}

def get_request_ip(request):
    ''' get client ip '''
    try:
        client_ip = request['HTTP_X_FORWARDED_FOR'].split(',')[-1].strip()
    except KeyError:
        client_ip = request.get("X-Real-IP", request.get("REMOTE_ADDR"))

    return client_ip

def authenticate(request, env_param):
    ''' md5 authenticate '''
    #param = get_global_param()

    m = hashlib.md5()
    client_ip = get_request_ip(request)

    authorization = request.get(settings.Authorization,None)
    logging.info('authorization in header is %s' % authorization)
    if not authorization:
        logging.error('%s has no authorization', client_ip)
        return False

    m.update(env_param)
    m.update(settings.SECRET)
    logging.info('authorization gen is %s' % m.hexdigest())
    ret = (m.hexdigest() == authorization)

    if not ret:
        logging.error('%s not authorized', client_ip)

    return ret


def uzip(env, env_param):
    #status:0 正常；1 解压失败；2 非法Content-Encoding
    #param = get_global_param()

    encoding = env.get('HTTP_CONTENT_ENCODING', None)
    status = 0
    data = None
    msg = None
    if encoding == 'gzip':
        buf = StringIO(env_param)
        try:
            gz_file = gzip.GzipFile(fileobj = buf)
            data = gz_file.read()
        except IOError, e:
            status = 1
            msg = 'request params should be compressed with gzip.'
            return [status, data, msg]
    elif encoding is None:
        data = env_param
    else:
        status = 2
        msg = 'only support gzip encoding.'
    return [status, data, msg]

def decode_des(content):
    global unpad,desObj
    res = unpad(desObj.decrypt(content))
    return res

def decode_base64(content):
    res = base64.decodestring(content)
    return res


def decode_content(env, content):
    ''' decode content '''
    code = env.get(settings.MOBILE_ENCRYPT, None)
    try:
        if code == '1':
            # des encryption
            result = decode_des(content)

        elif code == '2':
            # base64 encryption
            result = decode_base64(content)

        else:
            # no encryption
            result = content

        return result

    # decode failed, return None
    except Exception,e:
        logging.error(traceback.format_exc())
        logging.error("error info is %s" % e)
        return None

def check(data):
    if data:
        for c in data:
            if c != '0':
                return True
        return False
    else:
        return False

def get_gid(params):
    ''' get gid '''
    requests = params.get("requests",{})
    if types.DictionaryType == type(requests):
        mac = requests.get("mac", None)
        imei = requests.get("imei", None)
        imsi = requests.get("imsi", None)
        if mac and check(mac):
            return mac

        elif imei and check(imei):
            return imei

        elif imsi and check(imsi):
            return imsi

    #生成gid
    global g_gid_num, g_machine_id, g_process_id, g_gid_lock

    g_gid_lock.acquire()

    g_gid_num += 1
    logging.debug("gid: %s%08x%08x%x",g_machine_id, g_process_id, g_gid_num, int(time.time()))
    gid = "%s%08x%08x%x" % (g_machine_id, g_process_id, g_gid_num, int(time.time()))

    g_gid_lock.release()

    return gid



def extract_time(gid):
    ''' extract time from gid '''
    if (len(gid) == 40) or (len(gid) == 32):
        gid_time = long(gid[-8:], 16)
    elif len(gid) >= 45:
        gid_time = long(gid[-13:], 16) / 1000000.0
    else:
        gid_time = 0
    return gid_time


def get_gid_from_cookie(environ, param) :
    '''
    从cookie中提取gid或者生成新的gid，规则如下：
    1. 如果存在cookie，取cookie中的bfdid，如果cookie中的bfdid的长度<=8，则bfdid=None；
    2. 取参数中的f参数为fid，如果不存在或长度<=8，fid=请求参数中的gid参数的值；
    3. 如果存在fid，且fid ！= bfdid：
            如果存在bfdid：对比fid和bfdid中的时间戳，把最老的值，赋值给bfdid，如果是fid，则set_cookie=True
            如果不存在bfdid：bfdid = fid，set_cookie = True
    4. 如果bfdid为空：
            bfdid= 新生成的gid,  is_new = '1’,  set_cookie = True
    '''
    bfdid = None
    set_cookie = False
    is_new = '0'
    cookie_string = environ.get("HTTP_COOKIE", "")
    cookies = Cookie.SimpleCookie()
    if cookie_string:
        try:
            cookies.load(cookie_string)
        except Exception, e:
            logging.error(traceback.format_exc())
            logging.error("error info is %s" % e)

        if cookies.has_key("bfdid") :
            bfdid = cookies["bfdid"].value
            if len(bfdid) <= 8:
                bfdid = None

    fid = param.get('f', None)
    if (not fid) or len(fid) <= 8:
        fid = param.get('gid', None)

    if fid and fid != bfdid:
        if bfdid:
            fid_time = extract_time(fid)
            bfdid_time = extract_time(bfdid)
            if fid_time and fid_time < bfdid_time:
                bfdid = fid
                set_cookie = True
            if not bfdid_time:
                bfdid = None
        else:
            bfdid = fid
            set_cookie = True

    if not bfdid:
        bfdid = get_gid(param)
        is_new = '1'
        set_cookie = True
    logging.debug("get gid from cookie:bfdid=%s, is_new=%s, set_cookie=%s, cookies=%s", bfdid, is_new, set_cookie, cookies)

    return [bfdid, is_new, set_cookie, cookies]

def get_domain(request):
    domain = ''
    host = str(request.get('HTTP_HOST', ''))
    index = host.find(':')
    if -1 != index:
        host = host[:index]

    # host such as 'www.baidu.com' or 'ds.api.baifendian.com'
    m = re.match(r"(\D+\.){2,3}\D+", host)
    if m:
        domain = ('.').join(host.split('.')[-2:])
    else:
        # logging.error('the host %s is not a domain' % host)

        # host such as '172.18.1.22'
        m = re.match(r"(\d+\.){2,3}\d+", host)
        if m:
            domain = host

    logging.debug('the host is %s' % host)
    logging.debug('the domain is %s' % domain)
    return domain


def set_gid_cookie(headers, bfdid, domain):
    #在当前域名下设置cookie
    cookies = Cookie.SimpleCookie()
    cookies['bfdid'] = bfdid
    cookies['bfdid']['domain'] = domain
    cookies['bfdid']['path'] = '/'
    cookies['bfdid']['expires'] = settings.COOKIES_EXPIRE
    cstr = str(cookies)[12:]
    headers.append(("Set-Cookie", cstr))
    logging.debug('cookie is %s' % cstr)
    logging.debug('headers is %s' % json.dumps(headers))



def split_requests(info):
    ''' split Multi method'''
    req_list = []

    if type(info) is not dict:
        logging.error('format error: %s', info)
        return req_list
    requests = info.get('requests', None)

    if type(requests) is not list:
        logging.error('format error: %s', info)
        return req_list

    del info['requests']

    for req in requests:
        if type(req) is not dict:
            logging.error('request format error: %s', req)
            continue

        req.update(info)
        req_list.append(req)

    return req_list



def call_rpc(req_str):
    '''call the rpc'''
    global g_rpc_client

    s_time = time.time()

    try:
        ret = g_rpc_client.getResponse(req_str)
        logging.info('rpc return is %s' % ret)
        try:
            ret = json.loads(ret)
        except:
            pass

    except Exception, e:
        logging.error(traceback.format_exc())
        logging.error("error info is %s" % e)
        ret = [4, "Interal Error: dataProcessService occurs error!!!"]

    e_time = time.time()

    all_time = int( (e_time - s_time) * 1000)

    # add rpc time
    if types.ListType == type(ret) and settings.SHOW_TIME:
        time_info = {}
        time_info['ds_time'] = all_time
        ret.append(time_info)

    return ret

def zk_listener(state):
    """
    zk 状态变化监听事件
    :param state:
    :return:
    """
    logging.info('zk_state is change:%s' % state)






